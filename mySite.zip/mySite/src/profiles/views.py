from django.contrib.auth.decorators import login_required
from django.shortcuts import render

# Create your views here.
def index(request):
	context = {}
	template = 'index.html'
	return render(request,template,context)

def aboutus(request):
	context = {}
	template = 'aboutus.html'
	return render(request,template,context)


@login_required
def userProfile(request):
	user = request.user
	context = {'user': user}
	template = 'profile.html'
	return render(request,template,context)

